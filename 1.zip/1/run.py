import os
import main

def main_wrapper():
    # 设置 CUDA 设备
    os.environ["CUDA_VISIBLE_DEVICES"] = "0"

    # 直接调用 main.py 的 main() 函数并传入参数
    main.main(
        mode="train",
        model_type="DDIM",
        img_size=128,
        num_img_channels=1,
        dataset="sar",
        img_dir="DATA_FOLDER",
        train_batch_size=4,
        eval_batch_size=4,
        num_epochs=1,
        seg_dir="MASK_FOLDER",
        segmentation_guided=True,
        num_segmentation_classes=8,
        segmentation_channel_mode="single"  # 显式传递默认值
    )


if __name__ == "__main__":
    main_wrapper()
    print('main')
